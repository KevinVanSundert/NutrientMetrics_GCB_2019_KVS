############################################################

# Invited GCB paper

#    "Towards comparable assessment of the 
#        soil nutrient status across scales - 
#         review and development of nutrient metrics "

# Statistics on European ICP forests database

# Note: to minimize script length, 
#   R code to make Figs. and check model assumptions is not
#   shown here. 
#   Linear model assumptions (normality of residuals, 
#   linearity, homoscedasticity, ...) were checked with
#   standard functions built in in R (eg diagnostic plots,
#   shapiro test). Right-skewed variables were 
#   log-transformed; variance inflation factor was assessed
#   with the function vif() from package car.
#   possible interactions between covariates were detected
#   with regression trees (package tree)
#   Non-linearities were investigated with function gam()
#   from the mgcv package.

############################################################

Tablez = read.table("GCB_ICP.txt",header=T)
attach(Tablez)

############################################################

# 1. Normalization of productivity =
#      removing (confounding) effects 
#      of climate, species and stand age

############################################################

### TABLE S5 ###
### Correlations among some potentially important soil variables, 
###   and especially with climate

cor.test(MAT,log(MAP))

### TABLES S7, S8 AND S9c ###
### Structural equation model including direct and indirect climate effects 
###   through soil characteristics on productivity per species
###   to successfully calculate SEM parameters. 

logCNorg = log(CNorg)
logSOC020 = log(SOC020)
logMAP = log(MAP)

library(lavaan)

y = cbind(Prod,MAT,logCNorg,logSOC020,logMAP,AgeClass,species)

model <- ' 

### regression
Prod ~  MAT + logMAP + AgeClass + logCNorg + logSOC020

## 
## # residual covariances
logCNorg ~~ MAT
logSOC020 ~~ logMAP

'

fit <- sem(model, data=y, missing="two.stage", group="species")
summary(fit,standardized=T,fit.measures=T)

### Normalizing productivity for species, age and direct climate influence based on SEM output

NormProd.Beech = Prod[species=="beech"] - (0.169*MAT[species=="beech"]-0.756*log(MAP[species=="beech"])-0.739*AgeClass[species=="beech"])
NormProd.Oak = Prod[species=="oak"] - (0.841*MAT[species=="oak"]-18.746*log(MAP[species=="oak"])+0.221*AgeClass[species=="oak"])
NormProd.Spruce = Prod[species=="spruce"] - (0.102*MAT[species=="spruce"]+4.708*log(MAP[species=="spruce"])-1.082*AgeClass[species=="spruce"])
NormProd.Pine = Prod[species=="pine"] - (0.126*MAT[species=="pine"]-4.516*log(MAP[species=="pine"])-0.801*AgeClass[species=="pine"])

Future.NormProd = c(NormProd.Beech,NormProd.Oak,NormProd.Pine,NormProd.Spruce)

lm1 = lm(Future.NormProd ~ species - 1)
summary(lm1)

NormProd.Beech = Future.NormProd[species == "beech"] - 15.0087
NormProd.Oak = Future.NormProd[species == "oak"] - 116.5113
NormProd.Spruce = Future.NormProd[species == "spruce"] + 17.0742
NormProd.Pine = Future.NormProd[species == "pine"] - 37.0197

NormProd = c(NormProd.Beech,NormProd.Oak,NormProd.Pine,NormProd.Spruce)

### Table S9 ###

### Regression model: Productivity ~ climate + age (a)

lm1.Spruce = lm(Prod[species=="spruce"] ~ MAT[species=="spruce"] + log(MAP[species=="spruce"]) + AgeClass[species=="spruce"] )
lm1.Pine = lm(Prod[species=="pine"] ~ MAT[species=="pine"] + log(MAP[species=="pine"]) + AgeClass[species=="pine"] )
lm1.Beech = lm(Prod[species=="beech"] ~ MAT[species=="beech"] + log(MAP[species=="beech"]) + AgeClass[species=="beech"] )
lm1.Oak = lm(Prod[species=="oak"] ~ MAT[species=="oak"] + log(MAP[species=="oak"]) + AgeClass[species=="oak"] )
summary(lm1.Oak)

a.Beech = Prod[species=="beech"] - (-0.01894*MAT[species=="beech"]-4.79065*log(MAP[species=="beech"])-0.88243*AgeClass[species=="beech"])
a.Oak = Prod[species=="oak"] - (0.3679*MAT[species=="oak"]-6.1561*log(MAP[species=="oak"])-0.2803*AgeClass[species=="oak"])
a.Spruce = Prod[species=="spruce"] - (0.6564*MAT[species=="spruce"]+5.0253*log(MAP[species=="spruce"])-0.9528*AgeClass[species=="spruce"])
a.Pine = Prod[species=="pine"] - (0.5321*MAT[species=="pine"]-3.9900*log(MAP[species=="pine"])-0.5195*AgeClass[species=="pine"])

### Parameters with regression model: Productivity ~ climate + age + soil (b)

lm1.Spruce = lm(Prod[species=="spruce"] ~ MAT[species=="spruce"] + log(MAP[species=="spruce"]) + AgeClass[species=="spruce"] + log(CNorg[species=="spruce"]) + log(SOC020[species=="spruce"]))
lm1.Pine = lm(Prod[species=="pine"] ~ MAT[species=="pine"] + log(MAP[species=="pine"]) + AgeClass[species=="pine"] + log(CNorg[species=="pine"]) + log(SOC020[species=="pine"]))
lm1.Beech = lm(Prod[species=="beech"] ~ MAT[species=="beech"] + log(MAP[species=="beech"]) + AgeClass[species=="beech"] +  log(CNorg[species=="beech"]) + log(SOC020[species=="beech"]))
lm1.Oak = lm(Prod[species=="oak"] ~ MAT[species=="oak"] + log(MAP[species=="oak"]) + AgeClass[species=="oak"] + log(CNorg[species=="oak"]) + log(SOC020[species=="oak"]))
summary(lm1.Beech)

b.Beech = Prod[species=="beech"] - (-0.106*MAT[species=="beech"]-1.101*log(MAP[species=="beech"])-0.499*AgeClass[species=="beech"])
b.Oak = Prod[species=="oak"] - (0.859*MAT[species=="oak"]-20.211*log(MAP[species=="oak"])+0.144*AgeClass[species=="oak"])
b.Spruce = Prod[species=="spruce"] - (0.557*MAT[species=="spruce"]+1.473*log(MAP[species=="spruce"])-0.706*AgeClass[species=="spruce"])
b.Pine = Prod[species=="pine"] - (0.0545*MAT[species=="pine"]-4.2486*log(MAP[species=="pine"])-0.6752*AgeClass[species=="pine"])

Future.a = c(a.Beech,a.Oak,a.Pine,a.Spruce)
Future.b = c(b.Beech,b.Oak,b.Pine,b.Spruce)

lm1 = lm(Future.a ~ species - 1)
summary(lm1)

a.Beech = Future.a[species == "beech"] - 43.7851
a.Oak = Future.a[species == "oak"] - 42.9728
a.Spruce = Future.a[species == "spruce"] + 22.9191
a.Pine = Future.a[species == "pine"] - 30.0661

b.Beech = Future.b[species == "beech"] - 18.536
b.Oak = Future.b[species == "oak"] - 126.126
b.Spruce = Future.b[species == "spruce"] + 0.220
b.Pine = Future.b[species == "pine"] - 35.211

a = c(a.Beech,a.Oak,a.Pine,a.Spruce)
b = c(b.Beech,b.Oak,b.Pine,b.Spruce)

cor.test(b,NormProd)

############################################################

# 2. Testing the metric of Van Sundert et al. (2018)
#      & the original IIASA-metric
#      against ICP forests

############################################################

### TABLE 1 ###
### Evaluation of the metric

evaluation = lm(NormProd ~ Metric)
evaluation = lm(NormProd[species=="spruce"] ~ Metric[species=="spruce"])
summary(evaluation)

### TABLES S22 AND S25, AND FIG. 5
### Potential of organic vs mineral soil characteristics 
###  to explain spatial variation in Norm

lm1 = lm(NormProd ~ log(CNmin))
lm1 = lm(NormProd[species=="beech"] ~ log(CPmin[species=="beech"]))
summary(lm1)

### TABLE S21 ###

evaluation = lm(NormProd ~ IIASA_020)
evaluation = lm(NormProd[species=="beech"] ~ IIASA_020[species=="beech"])
summary(evaluation)

############################################################

# 3. Evaluation of the adjusted metric
#       & regression equation derived from Swedish DB

############################################################

### FIG 4 & TABLE 1 ###
# Metric & regression potential to explain spatial variation in normalized productivity

evaluation = lm(NormProd ~ AdjMetric)
evaluation.Spruce = lm(NormProd[species=="spruce"] ~ AdjMetric[species=="spruce"])
evaluation.Pine = lm(NormProd[species=="pine"] ~ AdjMetric[species=="pine"])
evaluation.Beech = lm(NormProd[species=="beech"] ~ AdjMetric[species=="beech"])
evaluation.regr = lm(NormProd ~ Regression)
evaluation.regrSpruce = lm(NormProd[species=="spruce"] ~ Regression[species=="spruce"])
evaluation.regrPine = lm(NormProd[species=="pine"] ~ Regression[species=="pine"])
evaluation.regrBeech = lm(NormProd[species=="beech"] ~ Regression[species=="beech"])
summary(evaluation.Pine)

### TABLES 2 & S24 ###
# Variable implementation in metric & derived regression function

set2=data.frame(Tablez,ResiduAdjMetric=NA,ResiduRegr=NA)
set2[names(residuals(evaluation.Beech)),"ResiduAdjMetric"]=residuals(evaluation.Beech)
set2[names(residuals(evaluation.regrBeech)),"ResiduRegr"]=residuals(evaluation.regrBeech)

implementation=lm(set2$ResiduAdjMetric[species=="beech"] ~ log(SOC020[species=="beech"]))
summary(implementation)

############################################################

# 4. Soil data or foliar stoichiometry for metric development?

############################################################

detach(Tablez)
rm(list=ls())
Tablez = read.table("GCB_ICP_PCA.txt",header=T)
Tablez.spruce = read.table("GCB_ICP_PCA_spruce.txt",header=T)
Tablez.pine = read.table("GCB_ICP_PCA_pine.txt",header=T)
Tablez.beech = read.table("GCB_ICP_PCA_beech.txt",header=T)
attach(Tablez)

log_CNorg = log(CNorg)
log_SOC = log(SOC020)
log_TEBmin = log(TEBmin)
log_CPmin = log(CPmin)

### TABLE S19 & S20 ###
### Correlation structure: Pearson's r
cor.test(leaf_n,leaf_p)

### FIG. 3a ###
### Correlation structure: PCA
y=cbind(log_CNorg,log_SOC,pHCaCl2org,log_TEBmin,log_CPmin)
y=y[complete.cases(y),]
pairs(y)
pc2=princomp(y,cor=T)
loadings(pc2)
summary(pc2)
screeplot(pc2)
par(mfrow=c(1,1))
biplot(pc2,pc.biplot=T)

### FIG. 3b ###
### Correlation structure: PCA
y=cbind(leaf_n,leaf_s,leaf_p,leaf_ca,leaf_mg,leaf_k,leaf_np)
y=y[complete.cases(y),]
pairs(y)
pc2=princomp(y,cor=T)
loadings(pc2)
summary(pc2)
screeplot(pc2)
par(mfrow=c(1,1))
biplot(pc2,pc.biplot=T)

### Stepwise regression

library(DAAG)

### TABLES S10-S18 ###
# Regression models to compare ability of soil vs stoichiometry variables to explain var in Normalized productivity
# performed with CVlm function, as in the example below

# e.g. selected model of Table S10:
CVlm(data=Tablez.beech,m=10,form.lm=formula(NormProd ~ log(CPmin) + log(SOC020)))

lm1 = lm(NormProd ~ explanatory variables)
summary(lm1)

 ############################################################

# E N D

 ############################################################

detach(Tablez)
rm(list=ls())

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
 # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
 # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #