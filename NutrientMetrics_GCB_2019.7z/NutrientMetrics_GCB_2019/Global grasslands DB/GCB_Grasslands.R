############################################################

# Invited GCB paper

#    "Adjustment and evaluation of
#         a soil-based nutrient availability metric"

# Statistics on global grasslands database

############################################################

Tablezz = read.table("GCB_grasslands.txt",header=T)
attach(Tablezz)

############################################################

# Note: to minimize script length, 
#   R code to make Figs. and check model assumptions is not
#   shown here. 
#   Linear model assumptions (normality of residuals, 
#   linearity, homoscedasticity, ...) were checked with
#   standard functions built in in R (eg diagnostic plots,
#   shapiro test). Right-skewed variables were 
#   log-transformed; variance inflation factor was assessed
#   with the function vif() from package car.
#   possible interactions between covariates were detected
#   with regression trees (package tree)
#   Non-linearities were investigated with function gam()
#   from the mgcv package.

############################################################

# 1. Normalization of productivity =
#      removing (confounding) effects of climate

############################################################

### TABLE S6 ###
### Correlations among some potentially important soil variables, 
###   and especially with climate

cor.test(log(KCaMgmin),log(Cmin))

### TABLES S7, S8 AND S9c ###
### Structural equation model including direct and indirect climate effects 
###   through soil characteristics on productivity per species
###   to successfully calculate SEM parameters. 

logANPP = log(ANPP)
logPrecip = log(Precgrs)
logCmin = log(Cmin)
logCmin2 = log(Cmin)*log(Cmin)
logCNmin = log(CNmin)
y=cbind(logANPP,MAT,logPrecip,pHmin,logCNmin,logCmin,logCmin2)

library(lavaan)

model <- ' 

### Nutrient availability definition (latent variable)

### regressions
logANPP ~  MAT + logPrecip + pHmin + logCNmin + logCmin + logCmin2

## 
## # residual covariances
pHmin ~~ logPrecip
pHmin ~~ logCmin
logCNmin ~~ logCmin
logCmin ~~ logPrecip
logCNmin ~~ logPrecip
pHmin ~~ logCNmin
logCmin ~~ logCmin2
pHmin ~~ logCmin2
logCNmin ~~ logCmin2
logCmin2 ~~ logPrecip

'

fit <- sem(model, data=y,missing="two.stage")
summary(fit,standardized=T,fit.measures=T)

NormProd = log(ANPP) - (-0.007*MAT+0.376*log(Precgrs))

lm1 = lm(NormProd ~ 1)
summary(lm1)
NormProd = NormProd - 3.37797
write.table(NormProd, "2NormProd.txt", sep="\t")

### Table S9 ###

### Regression model: Productivity ~ climate (a)

lm.Clim=lm(log(ANPP)~MAT+log(Precgrs))
summary(lm.Clim)

Future.a = log(ANPP) - (-0.01861*MAT+0.74055*log(Precgrs))

### Parameters with regression model: Productivity ~ climate + soil (b)

lm.ClimSoil=lm(log(ANPP)~MAT+log(Precgrs)+pHmin+I(log(Cmin)^2)+log(Cmin)+log(CNmin))
summary(lm.ClimSoil)

Future.b = log(ANPP) - (-0.006578*MAT+0.376109*log(Precgrs))

lm1 = lm(Future.b ~ 1)
summary(lm1)

a = Future.a - 1.17549
b = Future.b - 3.37288

cor.test(b,NormProd)

############################################################

# 2. Testing the metric of Van Sundert et al. (2018)
#      + adjusted metric
#      + derived regression equation
#      against global grassland DB

############################################################

### TABLE 1 AND FIG. 6 ###
### Evaluation of the metrics

evaluation = lm(NormProd ~ Metric)
evaluation.Adj = lm(NormProd ~ AdjMetric)
evaluation.Regr = lm(NormProd ~ Regression)
summary(evaluation.Adj)

### TABLES 2 AND S24  ###
### Variable implementation in metric

implementation=lm(evaluation.Regr$residuals~pHmin)
summary(implementation)

############################################################

detach(Tablezz)
rm(list=ls())


