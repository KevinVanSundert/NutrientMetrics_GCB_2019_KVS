############################################################

# Invited GCB paper

#    "Adjustment and evaluation of
#         a soil-based nutrient availability metric"

# Statistics on Swedish database

# Note: to minimize script length, 
#   R code to make Figs. and check model assumptions is not
#   shown here. 
#   Linear model assumptions (normality of residuals, 
#   linearity, homoscedasticity, ...) were checked with
#   standard functions built in in R (eg diagnostic plots,
#   shapiro test). Right-skewed variables were 
#   log-transformed; variance inflation factor was assessed
#   with the function vif() from package car.
#   possible interactions between covariates were detected
#   with regression trees (package tree)
#   Non-linearities were investigated with function gam()
#   from the mgcv package.

############################################################

Tables = read.table("GCB_Sweden.txt",header=T)
attach(Tables) 

############################################################

# 1. Normalization of productivity = 
#      removing (confounding) effects of climate and species 

############################################################

### TABLE S4 ###
### Correlations among some potentially important soil variables, 
###   and especially with climate

cor.test(TSUM,MAP)

### TABLES S7, S8 AND S9c ###
### Structural equation model including direct and indirect climate effects 
###   through soil characteristics on productivity per species
###   to successfully calculate SEM parameters. 

library(lavaan)

# Need to divide variables temporarily by a constant because lavaan dannot deal with too small parameter estimates.
TSUMquad_e6 = TSUM*TSUM/1000000
TSUM_e3 = TSUM/1000
MAP_e3 = MAP/1000
logSOC020 = log(SOC020)

y = cbind(Productivity,TSUMquad_e6,TSUM_e3,CNorg,logSOC020,MAP_e3,Species)

model <- ' 

### regressions
Productivity ~ TSUMquad_e6 + TSUM_e3 + MAP_e3 + CNorg + logSOC020

### residual covariances
CNorg ~~ TSUM_e3
logSOC020 ~~ MAP_e3

'

fit <- sem(model, data=y,missing="two.stage",group="Species")
summary(fit,standardized=T,fit.measures=T)

### Normalizing productivity for species and direct climate influence based on SEM output

Norm.Spruce = Productivity[Species=="Spruce"] - (8.116*10^-6*TSUM[Species=="Spruce"]*TSUM[Species=="Spruce"]-6.361*10^-3*TSUM[Species=="Spruce"]+1.053*10^-3*MAP[Species=="Spruce"])
Norm.Pine = Productivity[Species=="Pine"] - (-3.039*10^-6*TSUM[Species=="Pine"]*TSUM[Species=="Pine"]+11.191*10^-3*TSUM[Species=="Pine"]+0.243*10^-3*MAP[Species=="Pine"])

Future.NormProd = c(Norm.Spruce,Norm.Pine)

# Set average normalized productivity of both species to zero

lm1 = lm(Future.NormProd ~ Species - 1)
summary(lm1)

NormProd.Spruce = Future.NormProd[Species == "Spruce"] - 2.35955
NormProd.Pine = Future.NormProd[Species == "Pine"] + 4.19835

NormProd = c(Norm.Spruce,Norm.Pine)

### Table S9 ###

### Regression model: Productivity ~ climate (a)

lm1 = lm(Productivity ~ I(TSUM^2) + TSUM + MAP + Species + I(TSUM^2):Species + TSUM:Species)
summary(lm1)

a.Spruce = Productivity[Species=="Spruce"] - (9.0*10^-6*TSUM[Species=="Spruce"]*TSUM[Species=="Spruce"]-8*10^-3*TSUM[Species=="Spruce"]+0.3*10^-3*MAP[Species=="Spruce"])
a.Pine = Productivity[Species=="Pine"] - (-3.0*10^-6*TSUM[Species=="Pine"]*TSUM[Species=="Pine"]+11.2*10^-3*TSUM[Species=="Pine"]+0.3*10^-3*MAP[Species=="Pine"])

Future.a = c(a.Spruce,a.Pine)

lm1 = lm(Future.a ~ Species - 1)
summary(lm1)

a.Spruce = Future.a[Species == "Spruce"] - 3.54619
a.Pine = Future.a[Species == "Pine"] + 4.29362

a = c(a.Spruce,a.Pine)

### Parameters with regression model: Productivity ~ climate + soil (b)

lm1.Spruce = lm(Productivity[Species=="Spruce"] ~ I(TSUM[Species=="Spruce"]^2) + TSUM[Species=="Spruce"] + MAP[Species=="Spruce"] + CNorg[Species=="Spruce"] + log(SOC020[Species=="Spruce"]))
lm1.Pine = lm(Productivity[Species=="Pine"] ~ I(TSUM[Species=="Pine"]^2) + TSUM[Species=="Pine"] + MAP[Species=="Pine"] + CNorg[Species=="Pine"] + log(SOC020[Species=="Pine"]))
summary(lm1.Spruce)

b.Spruce = Productivity[Species=="Spruce"] - (8.1*10^-6*TSUM[Species=="Spruce"]*TSUM[Species=="Spruce"]-7*10^-3*TSUM[Species=="Spruce"]+1.2*10^-3*MAP[Species=="Spruce"])
b.Pine = Productivity[Species=="Pine"] - (-3.0*10^-6*TSUM[Species=="Pine"]*TSUM[Species=="Pine"]+11*10^-3*TSUM[Species=="Pine"]+0.6*10^-3*MAP[Species=="Pine"])

Future.b = c(b.Spruce,b.Pine)

lm1 = lm(Future.b ~ Species - 1)
summary(lm1)

b.Spruce = Future.b[Species == "Spruce"] - 3.02159
b.Pine = Future.b[Species == "Pine"] + 4.28155

b = c(b.Spruce,b.Pine)

cor.test(a,b)

############################################################

# 2. Create and evaluate a new metric based on FH layer
#     of Swedish conifer forests
#     Dataset split up in calibration and validation set

############################################################

### TABLE S10 + Eqs. (5)-(6) ###
### Derive new regression equations for organic layer C:N ratio & pH,
###   to implement in new metrics (for pH, optimum fixed on 4.5 based on prior knowledge from ICP database)
### + compare performance of organic and mineral soil variables

detach(Tables)
rm(list=ls())
Tables = read.table("GCB_Sweden_CalSet.txt",header=T)
attach(Tables) 

lm1 = lm(NormProd ~ I(log(SOC020)^2) + log(SOC020)) 
summary(lm1)

### Eq. (7) ###
mod1 = nls(NormProd ~ a * (pHCaCl2org - 4.5)^2 + b, Tables)
summary(mod1)

detach(Tables)
rm(list=ls())

### TABLE 1 ###
### Evaluation of the original and adjusted metrics

Tables = read.table("GCB_Sweden_ValSet.txt",header=T)
attach(Tables) 

evaluation = lm(NormProd[AdjMetric!="NA"] ~ Metric[AdjMetric!="NA"])
evaluation.adj = lm(NormProd ~ AdjMetric)
evaluation.regr = lm(NormProd ~ Regression)
summary(evaluation)

############################################################

# 3. Multiple regression equation based on 
#  same variables as in metric

############################################################

detach(Tables)
rm(list=ls())
Tables = read.table("GCB_Sweden_CalSet.txt",header=T)
attach(Tables) 

## Deriving the regression equation

library(DAAG)

# 0: mse = 1.83
CVlm(data=Tables,m=10,form.lm=formula(NormProd ~ log(CNorg) + pHCaCl2org + log(SOC020) + I(pHCaCl2org^2) + I(log(SOC020)^2)) )
  # 1: mse = 1.88
  CVlm(data=Tables,m=10,form.lm=formula(NormProd ~ pHCaCl2org + log(SOC020) + I(pHCaCl2org^2) + I(log(SOC020)^2)))

### Eq. (8) ###  
  
lm1 = lm(NormProd ~ log(CNorg) + pHCaCl2org + log(SOC020) + I(pHCaCl2org^2) + I(log(SOC020)^2)) 
summary(lm1)

detach(Tables)
rm(list=ls())

############################################################

# 4. Evalutation of metrics at natural gradients

############################################################

### TABLE S11 ###

Gradient=read.table('Pine_GradientSoilMoisture.txt',header=T)
Gradient=read.table('Pine_GradientTEB.txt',header=T)
Gradient=read.table('Pine_GradientProductivity.txt',header=T)
Gradient=read.table('Spruce_GradientSoilMoisture.txt',header=T)
Gradient=read.table('Spruce_GradientProductivity.txt',header=T)

attach(Gradient)

evaluation=lm(Productivity ~ AdjMetric)
summary(evaluation)

detach(Gradient)
rm(list=ls())

############################################################

# E N D

############################################################

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
 # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
 # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #